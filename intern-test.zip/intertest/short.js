//Given a string of words, implement a function that returns the shortest word in the string.
function shortestWord(str) {
    
    const words = str.split(' ');

   
    let shortest = words[0];
    let shortestLength = shortest.length;

    for (let i = 1; i < words.length; i++) {
        const currentWord = words[i];
        if (currentWord.length < shortestLength) {
            shortest = currentWord;
            shortestLength = currentWord.length;
        }
    }

    return shortest;
}

const sentence = "Hello QuadB am tring to impress you";
console.log(shortestWord(sentence)); 
