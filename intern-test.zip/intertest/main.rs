//reverse of string
fn reverse_string(input: &str) -> String {
    let mut reversed = String::with_capacity(input.len());
    for ch in input.chars().rev() {
        reversed.push(ch);
    }
    reversed
}

fn main() {
    let input = "Hello, World!";
    let reversed = reverse_string(input);
    println!("{}", reversed);
}






//check prime or not
fn is_prime(n: u64) -> bool {
    if n <= 1 {
        return false;
    }
    for i in 2..n {
        if n % i == 0 {
            return false;
        }
    }
    true
}

fn main() {
    let num = 29; 
    println!("{} is {}prime", num, if is_prime(num) { "" } else { "not " });
}


