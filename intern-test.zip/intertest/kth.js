//Implement a function that returns the kth smallest element in a given array.
function kthSmallest(arr, k) {
    arr.sort((a, b) => a - b);

    return arr[k - 1];
}

const array = [6, 11, 4, 2, 19, 12];
const k = 3;

console.log("Kth smallest element:", kthSmallest(array, k)); 