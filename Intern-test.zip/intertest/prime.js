function isPrime(number) {
    if (number <= 1) {
        return false;
    }

    for (let i = 2; i <= number / 2; i++) {
        if (number % i === 0) {
            return false;
        }
    }

    return true;
}

const num1 = 3;
const num2 = 16;

console.log(`${num1} is prime: ${isPrime(num1)}`);
console.log(`${num2} is prime: ${isPrime(num2)}`); 
