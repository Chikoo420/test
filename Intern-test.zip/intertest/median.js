function findMedian(arr) {
    const n = arr.length;
    const middleIndex = parseInt(n / 2);

    if (n % 2 === 1) {
        return arr[middleIndex];
    } else {
        return (arr[middleIndex - 1] + arr[middleIndex]) / 2;
    }
}

// Example usage:
const sortedArray1 = [1, 2, 3, 4, 5,7,9];
const sortedArray2 = [1, 2, 3, 4, 5, 6,8,10];

console.log("Median of array 1:", findMedian(sortedArray1)); 
console.log("Median of array 2:", findMedian(sortedArray2)); 
