const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function isPalindrome(str) {
    const len = str.length;
    for (let i = 0; i < len / 2; i++) {
        if (str[i] !== str[len - i - 1]) {
            return false;
        }
    }
    return true;
}

rl.question("Enter a string to check :", (input) => {
    input = input.trim(); 
    if (isPalindrome(input)) {
        console.log("Yes, It's a palindrome!");
    } else {
        console.log("N0 , It's not a palindrome.");
    }
    rl.close();
});
